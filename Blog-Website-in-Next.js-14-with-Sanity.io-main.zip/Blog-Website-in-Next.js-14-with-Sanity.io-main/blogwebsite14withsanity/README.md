This is a [Next.js](https://nextjs.org/) blog-site frontend styled with [TailwindCSS](https://tailwindcss.com/) and designed to use with any Headless CMS. It has been tested with [Sanity.io] which is a popular headless CMS> (https://www.sanity.io/).

## Getting Started

* Clone the repo
- git clone <repo-link>
* Install the packages 
- npm i 

You're good to go!!

## Headless CMS
Connect with your Headless CMS (tested with sanity.io)
